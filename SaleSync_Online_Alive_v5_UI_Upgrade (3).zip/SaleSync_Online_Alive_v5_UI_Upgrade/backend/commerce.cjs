const {randomUUID}=require('node:crypto');
const {digest}=require('./security.cjs');
const CATEGORIES=['Electronics','Fashion','Home & Living','Beauty','Sports','Accessories'];
const DELIVERY_FIELDS=['name','phone','address','barangay','city','province','postal'];
const STAGES=['paid','processing','packed','shipped','out_for_delivery','delivered'];
function commerceService({db,config,settings,now,audit,fail}){
  let features={};
  let transactionDepth=0;
  function transaction(work){if(transactionDepth)return work();db.exec('BEGIN IMMEDIATE');transactionDepth++;try{const value=work();db.exec('COMMIT');return value;}catch(error){db.exec('ROLLBACK');throw error;}finally{transactionDepth--;}}
  function text(value,min,max){return typeof value==='string'&&value.trim().length>=min&&value.length<=max&&!/[\u0000-\u001f]/.test(value);}
  function fields(input,allowed){if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!allowed.includes(key)))fail(422,'UNKNOWN_FIELD','The request contains unsupported fields.');}
  function revision(input,current){if(!Number.isInteger(input)||input!==current)fail(409,'REVISION_CONFLICT','This record changed. Reload it before saving.',{revision:current});}
  function delivery(input){
    if(!input||typeof input!=='object'||Array.isArray(input)||!['name','address','barangay','city','province'].every(key=>text(input[key],2,160))||typeof input.phone!=='string'||!/^09\d{9}$/.test(input.phone)||typeof input.postal!=='string'||!/^\d{4}$/.test(input.postal))fail(422,'INVALID_DELIVERY','Enter a complete Philippine address, an 11-digit mobile beginning 09, and a four-digit postal code.');
    return Object.fromEntries(DELIVERY_FIELDS.map(key=>[key,input[key].trim()]));
  }
  function notification(userId,message,orderId=null){db.prepare('INSERT INTO notifications VALUES (?,?,?,?,NULL,?)').run(randomUUID(),userId,message,orderId,now());}
  function history(orderId,user,status,note){db.prepare('INSERT INTO order_history(order_id,actor_id,status,note,created_at) VALUES (?,?,?,?,?)').run(orderId,user?.id||null,status,note,now());}
  function move(productId,user,kind,delta,reservedDelta,reason,orderId=null){db.prepare('INSERT INTO inventory_movements VALUES (?,?,?,?,?,?,?,?,?)').run(randomUUID(),productId,orderId,user?.id||null,kind,delta,reservedDelta,reason,now());}
  const storeRow=id=>db.prepare('SELECT * FROM stores WHERE id=?').get(id);
  function storeView(row){return row&&{...JSON.parse(row.data),id:row.id,name:row.name,status:row.status,revision:row.revision};}
  function stores(all=false){return db.prepare(`SELECT * FROM stores ${all?'':"WHERE status='approved'"} ORDER BY name`).all().map(storeView);}
  function sellerStore(user,approved=true){const row=db.prepare('SELECT * FROM stores WHERE owner_id=?').get(user.id);if(!row||(approved&&row.status!=='approved'))fail(403,'SELLER_APPROVAL_REQUIRED','An approved seller store is required.');return row;}
  const isManager=user=>user?.role==='management';
  function ownedStore(user,id){const row=storeRow(id);if(!row)fail(404,'NOT_FOUND','Store not found.');if(!isManager(user)&&(row.owner_id!==user.id||row.status!=='approved'))fail(403,'FORBIDDEN','You cannot manage this store.');return row;}
  function productRow(id){const row=db.prepare('SELECT p.*,m.store_id,m.sku,m.revision,s.name AS store_name,s.status AS store_status FROM products p JOIN product_meta m ON m.product_id=p.id JOIN stores s ON s.id=m.store_id WHERE p.id=?').get(id);if(!row)fail(404,'NOT_FOUND','Product not found.');return row;}
  function reserved(id){return db.prepare("SELECT COALESCE(SUM(quantity),0) n FROM reservations WHERE product_id=? AND state='active'").get(id).n;}
  function productView(row){const p=JSON.parse(row.data),held=reserved(row.id);return {...p,rating:features.ratingSummary?.(row.id)||{average:0,count:0},seller:row.store_name,storeId:row.store_id,sku:row.sku,revision:row.revision,onHand:p.primary,reserved:held,primary:Math.max(0,p.primary-held),published:p.published&&row.store_status==='approved'};}
  function products({all=false,storeId}={}){return db.prepare('SELECT p.*,m.store_id,m.sku,m.revision,s.name AS store_name,s.status AS store_status FROM products p JOIN product_meta m ON m.product_id=p.id JOIN stores s ON s.id=m.store_id ORDER BY p.rowid').all().filter(row=>!storeId||row.store_id===storeId).map(productView).filter(p=>all||p.published);}
  function validPhoto(photo){return photo===''||typeof photo==='string'&&( /^assets\/(?:products\/[a-z0-9-]+\.svg|logo-email\.png)$/.test(photo)||/^\/assets\/uploads\/[a-f0-9-]+\.(png|jpg|webp)$/.test(photo)||/^https:\/\/images\.unsplash\.com\/[a-zA-Z0-9/_?=&.%+-]+$/.test(photo));}
  function validateProduct(p){
    const money=value=>Number.isFinite(value)&&value>=0.01&&value<=10000000&&Math.round(value*100)===Math.round(value*10000)/100;
    if(!text(p.name,2,120)||!text(p.description,0,2000)||!CATEGORIES.includes(p.category)||!text(p.sku,2,64)||!money(p.price)||!money(p.was)||p.was<p.price||!Number.isInteger(p.primary)||p.primary<0||p.primary>1000000||typeof p.published!=='boolean'||!validPhoto(p.photo))fail(422,'INVALID_PRODUCT','Check the product name, category, SKU, two-decimal prices, stock, description and image.');
    if(!p.spec||typeof p.spec!=='object'||Array.isArray(p.spec)||Object.keys(p.spec).length>20||Object.entries(p.spec).some(([key,value])=>!text(key,1,50)||!text(value,0,200)))fail(422,'INVALID_PRODUCT','Use at most 20 specifications with short text values.');
  }
  function saveProduct(user,id,input){
    fields(input,['revision','name','description','category','sku','price','was','primary','published','photo','spec','storeId','reason']);
    return transaction(()=>{
      const row=id?productRow(id):null;
      const current=row?JSON.parse(row.data):{id:'P-'+randomUUID(),name:'',description:'',category:'Electronics',price:1,was:1,primary:0,published:false,photo:'',fallback:'assets/logo-email.png',spec:{},badge:'',lowThreshold:5};
      if(row){ownedStore(user,row.store_id);revision(input.revision,row.revision);}
      const storeId=row?(input.storeId||row.store_id):(isManager(user)?input.storeId:sellerStore(user).id);
      if(typeof storeId!=='string')fail(422,'STORE_REQUIRED','Choose an approved store.');
      const store=ownedStore(user,storeId);if(store.status!=='approved')fail(409,'STORE_UNAVAILABLE','Approve the store before publishing products.');
      if(row&&store.id!==row.store_id)fail(422,'STORE_FIXED','Create a new listing to move a product to another store.');
      if(!isManager(user)&&input.storeId&&input.storeId!==store.id)fail(403,'FORBIDDEN','Products must belong to your approved store.');
      const next={...current,...Object.fromEntries(Object.entries(input).filter(([key])=>!['revision','storeId','reason'].includes(key))),seller:store.name};
      next.sku=input.sku||row?.sku||'';next.name=typeof next.name==='string'?next.name.trim():next.name;
      if(next.photo==='')next.photo=next.fallback;
      validateProduct(next);
      const duplicate=db.prepare('SELECT product_id FROM product_meta WHERE sku=? COLLATE NOCASE AND product_id<>?').get(next.sku,next.id);if(duplicate)fail(409,'DUPLICATE_SKU','This SKU is already in use.');
      const delta=next.primary-current.primary;
      if(row&&next.primary<reserved(id))fail(409,'RESERVED_STOCK','Stock cannot be reduced below active reservations.');
      if(row&&delta&&!text(input.reason,5,200))fail(422,'REASON_REQUIRED','Enter a stock adjustment reason of 5–200 characters.');
      if(row){db.prepare('UPDATE products SET data=? WHERE id=?').run(JSON.stringify(next),id);db.prepare('UPDATE product_meta SET store_id=?,sku=?,revision=revision+1 WHERE product_id=?').run(store.id,next.sku,id);}
      else {db.prepare('INSERT INTO products(id,data) VALUES (?,?)').run(next.id,JSON.stringify(next));db.prepare('INSERT INTO product_meta(product_id,store_id,sku) VALUES (?,?,?)').run(next.id,store.id,next.sku);}
      if(delta||!row)move(next.id,user,row?'adjustment':'opening',row?delta:next.primary,0,input.reason||'New product opening stock');
      audit(user,row?'PRODUCT_UPDATED':'PRODUCT_CREATED',{productId:next.id,storeId:store.id,fields:Object.keys(input)});
      return productView(productRow(next.id));
    });
  }
  function adjustStock(user,id,input){fields(input,['revision','delta','reason']);if(!Number.isInteger(input.delta)||!input.delta||Math.abs(input.delta)>1000000)fail(422,'INVALID_ADJUSTMENT','Use a non-zero whole-number adjustment.');const p=productRow(id);return saveProduct(user,id,{revision:input.revision,primary:JSON.parse(p.data).primary+input.delta,reason:input.reason});}
  function applyStore(user,input){
    fields(input,['name','description','tagline']);
    if(user.role!=='customer')fail(403,'FORBIDDEN','Only verified customer accounts can apply to sell.');
    if(!text(input.name,2,60)||!text(input.description,10,1000)||!text(input.tagline,2,140))fail(422,'INVALID_STORE','Enter a store name, description and tagline.');
    return transaction(()=>{
      if(db.prepare('SELECT id FROM stores WHERE owner_id=?').get(user.id))fail(409,'STORE_EXISTS','Your account already has a seller application or store.');
      if(db.prepare('SELECT id FROM stores WHERE name=? COLLATE NOCASE').get(input.name.trim()))fail(409,'STORE_NAME_TAKEN','Choose a different store name.');
      const id=randomUUID(),data={description:input.description.trim(),tagline:input.tagline.trim(),headline:'Discover '+input.name.trim(),accent:'#245ec4'};
      db.prepare("INSERT INTO stores(id,owner_id,name,status,data,created_at) VALUES (?,?,?,'pending',?,?)").run(id,user.id,input.name.trim(),JSON.stringify(data),now());audit(user,'SELLER_APPLIED',{storeId:id});return storeView(storeRow(id));
    });
  }
  function updateStore(user,id,input){
    fields(input,isManager(user)?['revision','status','reason','name','description','tagline','headline']:['revision','description','tagline','headline']);
    return transaction(()=>{
      const row=storeRow(id);if(!row)fail(404,'NOT_FOUND','Store not found.');if(!isManager(user))ownedStore(user,id);revision(input.revision,row.revision);
      const data=JSON.parse(row.data);for(const key of ['description','tagline','headline'])if(key in input){if(!text(input[key],2,key==='description'?1000:140))fail(422,'INVALID_STORE','Store text is invalid.');data[key]=input[key].trim();}
      let status=row.status;
      if('status' in input){if(!['approved','rejected','suspended'].includes(input.status)||!text(input.reason,5,200))fail(422,'INVALID_STORE','Choose an approval status and give a reason.');status=input.status;}
      const name=input.name||row.name;if(!text(name,2,60))fail(422,'INVALID_STORE','Store name is invalid.');
      if(db.prepare('SELECT id FROM stores WHERE name=? COLLATE NOCASE AND id<>?').get(name.trim(),id))fail(409,'STORE_NAME_TAKEN','Choose another store name.');
      db.prepare('UPDATE stores SET name=?,status=?,data=?,revision=revision+1 WHERE id=?').run(name.trim(),status,JSON.stringify(data),id);
      if(row.owner_id)notification(row.owner_id,'Your seller store is '+status+'.');
      audit(user,'STORE_UPDATED',{storeId:id,status,reason:input.reason||'Store profile update'});return storeView(storeRow(id));
    });
  }
  function quote(items,address,cfg=settings.current().data,context){
    if(!Array.isArray(items)||!items.length||items.length>30||items.some(line=>!line||typeof line!=='object'||Array.isArray(line)))fail(422,'INVALID_CART','Choose 1–30 valid cart lines.');
    const shippingAddress=delivery(address),ids=new Set();
    const lines=items.map(line=>{
      if(typeof line.id!=='string'||!line.id||line.id.length>100)fail(409,'INVALID_STOCK','Choose valid product IDs.');
      const p=productView(productRow(line.id));
      if(ids.has(p.id)||!p.published||!Number.isInteger(line.qty)||line.qty<1||line.qty>99||line.qty>p.primary)fail(409,'INVALID_STOCK','An item is unavailable or its quantity exceeds available stock.');
      ids.add(p.id);return {id:p.id,name:p.name,seller:p.seller,storeId:p.storeId,sku:p.sku,price:p.price,qty:line.qty};
    });
    const shippingCents=Math.round(cfg.store.shippingPerSeller*100)*new Set(lines.map(line=>line.storeId)).size;
    const result={lines,delivery:shippingAddress,shipping:shippingCents/100,totalCents:lines.reduce((sum,line)=>sum+Math.round(line.price*100)*line.qty,shippingCents)};return context?features.discountQuote(result,context):result;
  }
  function orderRow(id){const row=db.prepare('SELECT * FROM orders WHERE id=?').get(id);if(!row)fail(404,'NOT_FOUND','Order not found.');return row;}
  function orderView(row){
    const meta=db.prepare('SELECT * FROM order_meta WHERE order_id=?').get(row.id),payment=db.prepare('SELECT id,mode,status,amount_cents,currency FROM payment_attempts WHERE order_id=?').get(row.id);
    const shipments=db.prepare('SELECT sh.*,s.name AS seller FROM shipments sh JOIN stores s ON s.id=sh.store_id WHERE sh.order_id=? ORDER BY sh.id').all(row.id).map(({store_id,order_id,updated_at,...rest})=>({...rest,storeId:store_id,orderId:order_id,updatedAt:updated_at}));
    const record={...JSON.parse(row.data),id:row.id,status:row.status,total:row.total_cents/100,customerEmail:db.prepare('SELECT email FROM users WHERE id=?').get(row.user_id)?.email,createdAt:row.created_at,revision:meta?.revision||1,expiresAt:meta?.expires_at||null,payment:payment?{...payment,amount:payment.amount_cents/100}:null,shipments,history:db.prepare('SELECT status,note,created_at AS createdAt FROM order_history WHERE order_id=? ORDER BY id').all(row.id),returnRequest:db.prepare('SELECT id,status,reason,revision FROM return_requests WHERE order_id=?').get(row.id)||null};
    record.inventoryReserved=!!db.prepare("SELECT 1 FROM reservations WHERE order_id=? AND state='active' LIMIT 1").get(row.id);
    return features.describeOrder?features.describeOrder(row,record):record;
  }
  function readOrder(user,id){const row=orderRow(id);if(!isManager(user)&&row.user_id!==user.id)fail(404,'NOT_FOUND','Order not found.');return orderView(row);}
  function orders(user){return (isManager(user)?db.prepare('SELECT * FROM orders ORDER BY created_at DESC LIMIT 500').all():db.prepare('SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC LIMIT 500').all(user.id)).map(orderView);}
  function createOrder(user,input,key){
    fields(input,['items','delivery','voucherCode']);if(settings.current().data.maintenance.enabled)fail(503,'MAINTENANCE',settings.current().data.maintenance.message);
    // Validate input types before normalization; numeric postal codes are rejected with 422.
    const address=delivery(input.delivery);
    if(typeof key!=='string'||!/^[A-Za-z0-9_-]{16,100}$/.test(key))fail(422,'IDEMPOTENCY_REQUIRED','Send an Idempotency-Key header of 16–100 letters, digits, hyphens or underscores.');
    const requestHash=digest(JSON.stringify({items:input.items,delivery:address,...(input.voucherCode?{voucherCode:String(input.voucherCode).trim().toUpperCase()}:{})}));
    return transaction(()=>{
      const prior=db.prepare('SELECT * FROM order_meta WHERE user_id=? AND idempotency_key=?').get(user.id,key);
      if(prior){if(prior.request_hash!==requestHash)fail(409,'IDEMPOTENCY_CONFLICT','This checkout key was used for different order details.');return {order:orderView(orderRow(prior.order_id)),replayed:true};}
      const priced=quote(input.items,address,settings.current().data,{user,code:input.voucherCode});if(priced.totalCents<=0)fail(422,'ZERO_TOTAL','Checkout requires a positive total.');const id='EC-'+randomUUID().toUpperCase(),test=config.paymentMode==='local-test',status=test?'pending_payment':'awaiting_gateway',expiresAt=test?now()+config.reservationSeconds*1000:null;
      const data={lines:priced.lines,delivery:priced.delivery,shipping:priced.shipping,subtotal:priced.subtotal,discount:priced.discount,promotion:priced.promotion,paymentProvider:test?'Local test simulator':null,paymentConfigured:test,inventoryReserved:test};
      db.prepare('INSERT INTO orders(id,user_id,status,total_cents,data,created_at) VALUES (?,?,?,?,?,?)').run(id,user.id,status,priced.totalCents,JSON.stringify(data),now());
      db.prepare('INSERT INTO order_meta(order_id,user_id,idempotency_key,request_hash,expires_at,payment_mode) VALUES (?,?,?,?,?,?)').run(id,user.id,key,requestHash,expiresAt,config.paymentMode);
      for(const line of priced.lines){
        db.prepare('INSERT INTO order_items VALUES (?,?,?,?,?,?,?)').run(randomUUID(),id,line.id,line.storeId,line.qty,Math.round(line.price*100),JSON.stringify(line));
        if(test){db.prepare("INSERT INTO reservations VALUES (?,?,?,'active',?)").run(id,line.id,line.qty,expiresAt);db.prepare('UPDATE product_meta SET revision=revision+1 WHERE product_id=?').run(line.id);move(line.id,user,'reservation',0,line.qty,'Pending local test payment',id);}
      }
      for(const storeId of new Set(priced.lines.map(line=>line.storeId)))db.prepare('INSERT INTO shipments(id,order_id,store_id,status,updated_at) VALUES (?,?,?,?,?)').run(randomUUID(),id,storeId,status,now());
      if(test)db.prepare("INSERT INTO payment_attempts VALUES (?,?,?,'pending',?,'PHP',?,?)").run(randomUUID(),id,'local-test',priced.totalCents,now(),now());
      features.holdPromotion?.(id,user,priced);features.enqueueEmail?.('order_created',id);
      history(id,user,status,test?'Order created; stock reserved for a local test payment.':'Unpaid request saved; payment is disabled.');audit(user,'ORDER_CREATED',{orderId:id,mode:config.paymentMode});notification(user.id,test?'Your order is awaiting a local test payment.':'Your unpaid order request was saved.',id);
      return {order:orderView(orderRow(id)),replayed:false};
    });
  }
  function release(orderId,user,reason){
    features.promotionState?.(orderId,'released');
    for(const reservation of db.prepare("SELECT * FROM reservations WHERE order_id=? AND state='active'").all(orderId)){db.prepare("UPDATE reservations SET state='released' WHERE order_id=? AND product_id=?").run(orderId,reservation.product_id);db.prepare('UPDATE product_meta SET revision=revision+1 WHERE product_id=?').run(reservation.product_id);move(reservation.product_id,user,'release',0,-reservation.quantity,reason,orderId);}
  }
  function expire(){
    const expired=db.prepare("SELECT o.* FROM orders o JOIN order_meta m ON m.order_id=o.id WHERE o.status='pending_payment' AND m.expires_at<=?").all(now());
    if(!expired.length)return;
    transaction(()=>{for(const order of expired){if(!db.prepare("SELECT 1 FROM orders o JOIN order_meta m ON m.order_id=o.id WHERE o.id=? AND o.status='pending_payment' AND m.expires_at<=?").get(order.id,now()))continue;release(order.id,null,'Payment reservation expired');db.prepare("UPDATE orders SET status='payment_expired' WHERE id=? AND status='pending_payment'").run(order.id);db.prepare('UPDATE order_meta SET revision=revision+1 WHERE order_id=?').run(order.id);db.prepare("UPDATE payment_attempts SET status='expired',updated_at=? WHERE order_id=? AND status='pending'").run(now(),order.id);db.prepare("UPDATE shipments SET status='payment_expired',revision=revision+1,updated_at=? WHERE order_id=?").run(now(),order.id);history(order.id,null,'payment_expired','Reservation expired; no payment collected.');notification(order.user_id,'Your payment reservation expired; stock was released.',order.id);}});
  }
  function simulatePayment(user,paymentId,outcome){
    if(config.production||config.paymentMode!=='local-test')fail(404,'NOT_FOUND','Local payment simulation is disabled.');
    if(!['success','failed','expired','cancelled'].includes(outcome))fail(422,'INVALID_OUTCOME','Choose success, failed, expired or cancelled.');
    expire();
    return transaction(()=>{
      const payment=db.prepare('SELECT * FROM payment_attempts WHERE id=?').get(paymentId);if(!payment)fail(404,'NOT_FOUND','Payment not found.');
      const row=orderRow(payment.order_id);if(row.user_id!==user.id||user.role!=='customer')fail(404,'NOT_FOUND','Payment not found.');
      if(payment.mode!=='local-test')fail(403,'FORBIDDEN','This endpoint accepts only local test payments.');
      const eventId=digest(payment.id+':'+outcome),prior=db.prepare('SELECT id FROM payment_events WHERE id=?').get(eventId);
      if(prior)return {order:orderView(row),replayed:true};
      if(payment.status!=='pending'||row.status!=='pending_payment')fail(409,'PAYMENT_FINAL','This payment is already completed or expired.');
      if(payment.amount_cents!==row.total_cents||payment.currency!=='PHP')fail(409,'PAYMENT_MISMATCH','Payment amount does not match the saved order.');
      let status;
      if(outcome==='success'){
        const holds=db.prepare("SELECT * FROM reservations WHERE order_id=? AND state='active' AND expires_at>?").all(row.id,now());
        const lines=db.prepare('SELECT * FROM order_items WHERE order_id=?').all(row.id);if(holds.length!==lines.length)fail(409,'RESERVATION_LOST','The stock reservation is no longer valid.');
        for(const line of lines){const hold=holds.find(h=>h.product_id===line.product_id),p=productRow(line.product_id),data=JSON.parse(p.data);if(!hold||hold.quantity!==line.quantity||data.primary<line.quantity||p.store_status!=='approved')fail(409,'INVALID_STOCK','Reserved stock is unavailable.');data.primary-=line.quantity;db.prepare('UPDATE products SET data=? WHERE id=?').run(JSON.stringify(data),p.id);db.prepare('UPDATE product_meta SET revision=revision+1 WHERE product_id=?').run(p.id);db.prepare("UPDATE reservations SET state='committed' WHERE order_id=? AND product_id=?").run(row.id,p.id);move(p.id,user,'sale',-line.quantity,-line.quantity,'Local test payment confirmed',row.id);}
        status='paid';features.promotionState?.(row.id,'used');
      }else{release(row.id,user,'Local test payment '+outcome);status=outcome==='failed'?'payment_failed':outcome==='expired'?'payment_expired':'cancelled';}
      const paymentStatus=outcome==='success'?'paid':outcome;
      db.prepare('UPDATE payment_attempts SET status=?,updated_at=? WHERE id=?').run(paymentStatus,now(),payment.id);db.prepare('INSERT INTO payment_events VALUES (?,?,?,?)').run(eventId,payment.id,outcome,now());db.prepare('UPDATE orders SET status=? WHERE id=?').run(status,row.id);db.prepare('UPDATE order_meta SET revision=revision+1 WHERE order_id=?').run(row.id);db.prepare('UPDATE shipments SET status=?,revision=revision+1,updated_at=? WHERE order_id=?').run(status,now(),row.id);history(row.id,user,status,'Local test payment '+outcome+'; no real money moved.');notification(user.id,'Local test order '+row.id+' is '+status+'.',row.id);audit(user,'TEST_PAYMENT_'+outcome.toUpperCase(),{orderId:row.id,paymentId});return {order:orderView(orderRow(row.id)),replayed:false};
    });
  }
  function cancelOrder(user,id,input){fields(input,['revision','status']);return transaction(()=>{const row=orderRow(id);if(!isManager(user)&&row.user_id!==user.id)fail(404,'NOT_FOUND','Order not found.');const meta=db.prepare('SELECT revision FROM order_meta WHERE order_id=?').get(id);if(meta)revision(input.revision,meta.revision);if(!['pending_payment','awaiting_gateway'].includes(row.status))fail(422,'INVALID_TRANSITION','Only unpaid orders can be cancelled directly. Request a return or contact the store for a paid order.');release(id,user,'Unpaid order cancelled');db.prepare("UPDATE orders SET status='cancelled' WHERE id=?").run(id);db.prepare('UPDATE order_meta SET revision=revision+1 WHERE order_id=?').run(id);db.prepare("UPDATE payment_attempts SET status='cancelled',updated_at=? WHERE order_id=? AND status='pending'").run(now(),id);db.prepare("UPDATE shipments SET status='cancelled',revision=revision+1,updated_at=? WHERE order_id=?").run(now(),id);history(id,user,'cancelled','Unpaid order cancelled.');notification(row.user_id,'Your unpaid order was cancelled.',id);audit(user,'ORDER_CANCELLED',{orderId:id});return orderView(orderRow(id));});}
  function transitionShipment(user,id,input){
    fields(input,['revision','status','courier','tracking']);
    return transaction(()=>{
      const sh=db.prepare('SELECT * FROM shipments WHERE id=?').get(id);if(!sh)fail(404,'NOT_FOUND','Shipment not found.');ownedStore(user,sh.store_id);revision(input.revision,sh.revision);
      const row=orderRow(sh.order_id);if(!STAGES.includes(row.status))fail(422,'INVALID_TRANSITION','Only paid orders can be fulfilled.');
      const expected=STAGES[STAGES.indexOf(sh.status)+1];if(!expected||input.status!==expected)fail(422,'INVALID_TRANSITION','Follow the shipment stages in order.');
      const courier=input.courier??sh.courier,tracking=input.tracking??sh.tracking;
      if(!text(courier,0,100)||!text(tracking,0,100)||(input.status==='shipped'&&(!text(courier,2,100)||!text(tracking,2,100))))fail(422,'TRACKING_REQUIRED','Enter a courier and tracking reference before dispatch.');
      db.prepare('UPDATE shipments SET status=?,courier=?,tracking=?,revision=revision+1,updated_at=? WHERE id=?').run(input.status,courier.trim(),tracking.trim(),now(),id);
      const statuses=db.prepare('SELECT status FROM shipments WHERE order_id=?').all(row.id).map(s=>STAGES.indexOf(s.status)),status=STAGES[Math.min(...statuses)];
      db.prepare('UPDATE orders SET status=? WHERE id=?').run(status,row.id);db.prepare('UPDATE order_meta SET revision=revision+1 WHERE order_id=?').run(row.id);history(row.id,user,status,storeRow(sh.store_id).name+' shipment marked '+input.status.replaceAll('_',' ')+'.');notification(row.user_id,'Shipment update: '+input.status.replaceAll('_',' ')+'.',row.id);audit(user,'SHIPMENT_UPDATED',{orderId:row.id,shipmentId:id,status:input.status});if(['shipped','delivered'].includes(input.status))features.enqueueEmail?.(input.status,row.id,id);return orderView(orderRow(row.id));
    });
  }
  function sellerOrders(user){const store=sellerStore(user);return db.prepare('SELECT DISTINCT o.* FROM orders o JOIN shipments s ON s.order_id=o.id WHERE s.store_id=? ORDER BY o.created_at DESC LIMIT 300').all(store.id).map(row=>{const order=orderView(row);const lines=order.lines.filter(line=>line.storeId===store.id);return {id:order.id,status:order.status,createdAt:order.createdAt,delivery:order.delivery,lines,shipments:order.shipments.filter(sh=>sh.storeId===store.id),total:lines.reduce((sum,line)=>sum+line.price*line.qty,0),paymentMode:order.payment?.mode||'disabled'};});}
  function requestReturn(...args){return features.requestReturn(...args);}
  function updateReturn(...args){return features.updateReturn(...args);}
  function refundOrder(...args){return features.refundOrder(...args);}
  function reports(){return features.reports();}
  return {setFeatures:value=>{features=value;},transaction,text,fields,revision,delivery,notification,history,move,products,productRow,productView,stores,storeView,storeRow,sellerStore,ownedStore,saveProduct,adjustStock,applyStore,updateStore,quote,createOrder,orders,readOrder,orderRow,orderView,cancelOrder,expire,simulatePayment,transitionShipment,sellerOrders,requestReturn,updateReturn,refundOrder,reports};
}
module.exports={commerceService,CATEGORIES};
