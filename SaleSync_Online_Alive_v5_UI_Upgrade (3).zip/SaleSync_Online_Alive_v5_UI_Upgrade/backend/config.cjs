const fs = require('node:fs');
const path = require('node:path');
const { randomBytes } = require('node:crypto');
const ROOT = path.resolve(__dirname, '..');
function loadConfig(env = process.env) {
  const production = env.NODE_ENV === 'production';
  const dbPath = path.resolve(ROOT, env.DATABASE_PATH || 'data/salesync.sqlite');
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  let secret = env.APP_SECRET;
  if (!secret && !production) {
    const secretFile = path.join(path.dirname(dbPath), '.app-secret');
    if (!fs.existsSync(secretFile)) fs.writeFileSync(secretFile, randomBytes(48).toString('hex'), { mode: 0o600, flag: 'wx' });
    secret = fs.readFileSync(secretFile, 'utf8').trim();
  }
  if (!secret || secret.length < 32) throw Error('APP_SECRET must contain at least 32 characters.');
  if (production && env.COOKIE_SECURE !== 'true') throw Error('Production requires COOKIE_SECURE=true and HTTPS.');
  const port = Number(env.PORT || 3000);
  const origin = env.APP_ORIGIN || `http://127.0.0.1:${port}`;
  const paymentMode=env.PAYMENT_MODE||(production?'disabled':'local-test');
  const courierMode=env.COURIER_MODE||(production?'manual':'local-test');
  if(!['manual','local-test','aftership'].includes(courierMode)||(production&&courierMode==='local-test'))throw Error('Use manual, aftership or development-only local-test COURIER_MODE.');
  if(!['disabled','local-test'].includes(paymentMode)||(production&&paymentMode==='local-test'))throw Error('Use disabled or development-only local-test PAYMENT_MODE.');
  if (production && !origin.startsWith('https://')) throw Error('Production APP_ORIGIN must use HTTPS.');
  const num = (key, fallback, min, max) => {
    const n = Number(env[key] || fallback);
    if (!Number.isInteger(n) || n < min || n > max) throw Error(`${key} must be an integer between ${min} and ${max}.`);
    return n;
  };
  return { root: ROOT, dbPath, uploadDir:path.join(path.dirname(dbPath),'uploads'),secret, port, origin, host: env.HOST || '127.0.0.1', production,
    secureCookie: env.COOKIE_SECURE === 'true', sessionSeconds: num('SESSION_TTL_SECONDS', 28800, 300, 86400),paymentMode,reservationSeconds:num('RESERVATION_TTL_SECONDS',900,60,3600),courierMode,courierStepSeconds:num('COURIER_TEST_STEP_SECONDS',60,10,3600),
    initialSettings: {
      store: { name: 'SaleSync Online', tagline: 'Make room for your next favorite find.', supportEmail: '', shippingPerSeller: 69 },
      email: { ttlSeconds: num('VERIFICATION_TTL_SECONDS', 300, 60, 900), maxAttempts: num('VERIFICATION_MAX_ATTEMPTS', 5, 1, 5), resendSeconds: num('VERIFICATION_RESEND_SECONDS', 60, 60, 600), maxSendsPerHour: num('VERIFICATION_MAX_SENDS_PER_HOUR', 5, 1, 5) },
      maintenance: { enabled: false, message: 'We are making a few improvements. Please check back shortly.' }
    }, env };
}
module.exports = { loadConfig };
