const readline = require('node:readline/promises');
const { Writable } = require('node:stream');
const { loadConfig } = require('./config.cjs');
const { openDatabase } = require('./database.cjs');
const { provisionAdmin } = require('./app.cjs');
(async()=>{
  let muted=false;
  const output=new Writable({write(chunk,encoding,cb){if(!muted)process.stdout.write(chunk);cb();}});
  const rl=readline.createInterface({input:process.stdin,output,terminal:true});
  let db;
  try {
    const name=await rl.question('Administrator full name: ');
    const email=await rl.question('Individual Gmail address: ');
    const role=await rl.question('Role (maintenance / management): ');
    process.stdout.write('Password (12+ characters; hidden): ');muted=true;
    const password=await rl.question('');muted=false;process.stdout.write('\n');
    const config=loadConfig();db=openDatabase(config);
    await provisionAdmin(db,{name,email,password,role});
    console.log('Individual administrator account created. No existing account was changed.');
  } finally {rl.close();db?.close();}
})().catch(()=>{console.error('Could not create administrator. Check the fields, password length, and whether the Gmail account already exists.');process.exitCode=1;});
