const { loadConfig } = require('./config.cjs');
const { createApp } = require('./app.cjs');
(async()=>{
  const config=loadConfig(),app=await createApp(config);
  app.startWorkers();
  app.server.listen(config.port,config.host,()=>console.log(`SaleSync: ${config.origin} | API: ${config.origin}/api/v1/health`));
  for (const signal of ['SIGINT','SIGTERM']) process.on(signal,async()=>{await app.close();process.exit(0);});
})().catch(()=>{console.error('Unable to start SaleSync. Check the environment settings and database path.');process.exitCode=1;});
