const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {randomBytes,randomUUID,createHmac}=require('node:crypto');
const {loadConfig}=require('../backend/config.cjs');
const {createApp,provisionAdmin}=require('../backend/app.cjs');
const {hashPassword,gmailAddress}=require('../backend/security.cjs');
const PASSWORD='Feature test password 927!';
const ADDRESS={name:'Feature Buyer',phone:'09123456789',address:'123 Test Street',barangay:'Rosario',city:'Pasig',province:'Metro Manila',postal:'1609'};
async function fixture(t,options={}){
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'salesync-features-'));let timestamp=Date.now(),failMail=false;const sent=[];
  const config=loadConfig({DATABASE_PATH:path.join(directory,'qa.sqlite'),APP_SECRET:randomBytes(48).toString('hex'),APP_ORIGIN:'http://127.0.0.1:3000',MAIL_MODE:'disabled',PAYMENT_MODE:'local-test',...options.env});
  const app=await createApp(config,{now:()=>timestamp,courierFetch:options.fetchImpl,mailer:{configured:true,sendVerification:async()=>{},sendOrder:async(to,data,key)=>{if(failMail)throw Error('private SMTP message');sent.push({to,data,key});}}});
  await provisionAdmin(app.db,{name:'Feature Manager',email:'featuremanager@gmail.com',password:PASSWORD,role:'management'});await provisionAdmin(app.db,{name:'Feature Maintenance',email:'featuremaintenance@gmail.com',password:PASSWORD,role:'maintenance'});
  const passwordHash=await hashPassword(PASSWORD);for(const email of ['featurebuyer@gmail.com','featureother@gmail.com'])app.db.prepare("INSERT INTO users VALUES (?,?,?,?,?,'customer','active',?,?)").run(randomUUID(),'Feature Buyer',email,gmailAddress(email).key,passwordHash,timestamp,timestamp);
  await new Promise(resolve=>app.server.listen(0,'127.0.0.1',resolve));const base='http://127.0.0.1:'+app.server.address().port;
  t.after(async()=>{await app.close();assert.ok(path.resolve(directory).startsWith(path.resolve(os.tmpdir())+path.sep));fs.rmSync(directory,{recursive:true,force:true});});
  async function client(email){let cookie='',csrf='';const call=async(route,method='GET',body,headers={})=>{const response=await fetch(base+'/api/v1'+route,{method,headers:{Origin:config.origin,Cookie:cookie,...(csrf?{'X-CSRF-Token':csrf}:{}),...(body!==undefined?{'Content-Type':'application/json'}:{}),...headers},...(body!==undefined?{body:JSON.stringify(body)}:{})});if(response.headers.getSetCookie().length)cookie=response.headers.getSetCookie().map(v=>v.split(';')[0]).join('; ');return {status:response.status,data:await response.json()};};const login=await call('/auth/login','POST',{email,password:PASSWORD});assert.equal(login.status,200);csrf=login.data.csrfToken;return call;}
  const buyer=await client('featurebuyer@gmail.com'),other=await client('featureother@gmail.com'),manager=await client('featuremanager@gmail.com'),maintenance=await client('featuremaintenance@gmail.com');
  async function create(qty=3,code){const result=await buyer('/orders','POST',{items:[{id:'p1',qty}],delivery:ADDRESS,...(code?{voucherCode:code}:{})},{'Idempotency-Key':randomUUID()});assert.equal(result.status,201,JSON.stringify(result.data));return result.data.order;}
  async function pay(order){const result=await buyer('/payments/'+order.payment.id+'/simulate','POST',{outcome:'success'});assert.equal(result.status,200);return result.data.order;}
  async function deliver(order,stop='delivered'){for(const status of ['processing','packed','shipped','out_for_delivery','delivered']){const sh=order.shipments[0];const result=await manager('/admin/shipments/'+sh.id,'PATCH',{revision:sh.revision,status,courier:'Test Courier',tracking:'TEST-ONLY-927'});assert.equal(result.status,200,JSON.stringify(result.data));order=result.data.order;if(status===stop)break;}return order;}
  const product=(await manager('/admin/catalog')).data.products.find(p=>p.id==='p1');assert.equal((await manager('/admin/catalog/p1','PATCH',{revision:product.revision,price:10.01,was:20,primary:30,reason:'Set isolated test inventory'})).status,200);
  return {...app,config,base,buyer,other,manager,maintenance,client,create,pay,deliver,sent,advance:ms=>{timestamp+=ms;},failMail:value=>{failMail=value;}};
}
const promotion={code:'QA10',name:'Ten percent test',type:'percent',value:10,active:true,automatic:false,minSubtotal:0,maxDiscount:null,usageLimit:2,perCustomerLimit:1,startsAt:null,endsAt:null};
test('vouchers enforce dates, usage holds, ownership, integer-cent allocation and cancellation release',async t=>{
  const f=await fixture(t);assert.equal((await f.buyer('/admin/promotions','POST',promotion)).status,403);assert.equal((await f.maintenance('/admin/promotions')).status,403);const created=await f.manager('/admin/promotions','POST',promotion);assert.equal(created.status,201);
  const input={items:[{id:'p1',qty:3}],delivery:ADDRESS,voucherCode:'qa10'},quote=(await f.buyer('/orders/quote','POST',input)).data.quote;assert.equal(quote.discount,3);assert.equal(quote.lines[0].netCents,2703);assert.equal(quote.totalCents,9603);
  const order=await f.create(3,'QA10');assert.equal(order.total,96.03);assert.equal((await f.buyer('/orders/quote','POST',input)).status,422);assert.equal((await f.other('/orders/quote','POST',input)).status,200);
  assert.equal((await f.buyer('/orders/'+order.id+'/cancel','POST',{revision:order.revision})).status,200);assert.equal((await f.buyer('/orders/quote','POST',input)).status,200);
  assert.equal((await f.manager('/admin/promotions/'+created.data.promotion.id,'PATCH',{revision:1,endsAt:1})).status,200);assert.equal((await f.buyer('/orders/quote','POST',input)).status,422);
  assert.equal((await f.manager('/admin/promotions/'+created.data.promotion.id,'PATCH',{revision:1,active:false})).status,409);
});
test('automatic promotions select the best eligible discount and checkout rejects client-supplied totals',async t=>{
  const f=await fixture(t);for(const [code,value] of [['AUTO5',5],['AUTO20',20]])assert.equal((await f.manager('/admin/promotions','POST',{...promotion,code,value,automatic:true})).status,201);
  const result=await f.buyer('/orders/quote','POST',{items:[{id:'p1',qty:1}],delivery:ADDRESS});assert.equal(result.data.quote.discount,2);assert.equal(result.data.quote.promotion.code,'AUTO20');
  assert.equal((await f.buyer('/orders/quote','POST',{items:[{id:'p1',qty:1}],delivery:ADDRESS,total:0})).status,422);
  const [first,second]=await Promise.all([f.buyer('/orders','POST',{items:[{id:'p1',qty:1}],delivery:ADDRESS,voucherCode:'AUTO20'},{'Idempotency-Key':randomUUID()}),f.buyer('/orders','POST',{items:[{id:'p1',qty:1}],delivery:ADDRESS,voucherCode:'AUTO20'},{'Idempotency-Key':randomUUID()})]);assert.deepEqual([first.status,second.status].sort(),[201,422]);
});
test('partial returns/refunds use discounted paid amounts, block overlap, restock once and refund shipping only at completion',async t=>{
  const f=await fixture(t);await f.manager('/admin/promotions','POST',promotion);let order=await f.deliver(await f.pay(await f.create(3,'QA10')));
  const returned=await f.buyer('/orders/'+order.id+'/returns','POST',{reason:'Only one of the purchased units needs returning.',items:[{id:'p1',qty:1}]});assert.equal(returned.status,201);assert.equal((await f.other('/orders/'+order.id+'/returns','POST',{reason:'Try reading another customer order.',items:[{id:'p1',qty:1}]})).status,404);
  assert.equal((await f.buyer('/orders/'+order.id+'/returns','POST',{reason:'Try reserving too many return quantities.',items:[{id:'p1',qty:3}]})).status,409);
  let request=returned.data.returnRequest;for(const status of ['approved','received'])request=(await f.manager('/admin/returns/'+request.id,'PATCH',{revision:request.revision,status})).data.returnRequest;
  const key=randomUUID(),body={revision:order.revision,reason:'One returned unit was checked',restock:true,items:[{id:'p1',qty:1}],returnId:request.id,refundShipping:false};
  assert.equal((await f.manager('/admin/orders/'+order.id+'/refund','POST',body)).status,422);
  const refund=await f.manager('/admin/orders/'+order.id+'/refund','POST',body,{'Idempotency-Key':key});assert.equal(refund.status,200,JSON.stringify(refund.data));order=refund.data.order;assert.equal(order.refunded,9.01);assert.equal(order.status,'delivered');assert.equal(order.lines[0].returnableQty,2);
  assert.equal((await f.manager('/admin/orders/'+order.id+'/refund','POST',body,{'Idempotency-Key':key})).status,200);assert.equal(f.db.prepare('SELECT COUNT(*) n FROM refunds').get().n,1);assert.equal((await f.manager('/admin/orders/'+order.id+'/refund','POST',{...body,reason:'Different request content'}, {'Idempotency-Key':key})).status,409);
  request=(await f.buyer('/orders/'+order.id+'/returns','POST',{reason:'The remaining two units also need to be returned.',items:[{id:'p1',qty:2}]})).data.returnRequest;for(const status of ['approved','received'])request=(await f.manager('/admin/returns/'+request.id,'PATCH',{revision:request.revision,status})).data.returnRequest;
  const final=await f.manager('/admin/orders/'+order.id+'/refund','POST',{revision:order.revision,reason:'Remaining returned units checked',restock:true,items:[{id:'p1',qty:2}],returnId:request.id,refundShipping:true},{'Idempotency-Key':randomUUID()});assert.equal(final.status,200,JSON.stringify(final.data));assert.equal(final.data.order.refunded,96.03);assert.equal(final.data.order.status,'refunded');assert.equal(JSON.parse(f.db.prepare('SELECT data FROM products WHERE id=\'p1\'').get().data).primary,30);assert.equal((await f.manager('/admin/reports')).data.testRevenue,0);
});
test('reviews require delivered purchases, allow one versioned review per customer, and moderation updates ratings',async t=>{
  const f=await fixture(t);assert.equal((await f.buyer('/products/p1/reviews','PUT',{rating:5,body:'A helpful review before buying.'})).status,403);await f.deliver(await f.pay(await f.create(1)));
  const first=await f.buyer('/products/p1/reviews','PUT',{rating:5,body:'Excellent product and a good experience.'});assert.equal(first.status,200);assert.equal((await f.other('/products/p1/reviews','PUT',{rating:5,body:'Try claiming someone else purchase.'})).status,403);
  const list=await f.other('/products/p1/reviews');assert.equal(list.data.rating.average,5);assert.equal(list.data.reviews[0].verifiedPurchase,true);assert.ok(!JSON.stringify(list.data.reviews).includes('featurebuyer@gmail.com'));
  assert.equal((await f.buyer('/products/p1/reviews','PUT',{rating:4,body:'An updated verified purchase review.',revision:1})).status,200);assert.equal((await f.buyer('/products/p1/reviews','PUT',{rating:3,body:'A stale update should be rejected.',revision:1})).status,409);
  assert.equal((await f.maintenance('/admin/reviews')).status,403);const hidden=await f.manager('/admin/reviews/'+first.data.review.id,'PATCH',{revision:2,status:'hidden',reason:'Review needs a moderation check'});assert.equal(hidden.status,200);assert.equal((await f.other('/products/p1/reviews')).data.rating.count,0);
  await f.buyer('/products/p1/reviews','PUT',{rating:4,body:'Edited reviews must not bypass moderation.',revision:3});assert.equal((await f.other('/products/p1/reviews')).data.rating.count,0);
});
test('product/order pagination uses bounded stable pages, filters before counting and preserves order ownership',async t=>{
  const f=await fixture(t);const first=await f.buyer('/products?limit=3&page=1'),second=await f.buyer('/products?limit=3&page=2');assert.equal(first.data.products.length,3);assert.equal(first.data.pagination.total,12);assert.equal(first.data.products.some(a=>second.data.products.some(b=>a.id===b.id)),false);
  assert.equal((await f.buyer('/products?limit=101')).status,422);assert.equal((await f.buyer('/products?page=-1')).status,422);assert.equal((await f.buyer('/products?q=notfound927')).data.pagination.total,0);assert.equal((await f.buyer('/products?q=%25')).data.pagination.total,0);
  for(let i=0;i<3;i++)await f.create(1);const orders=await f.buyer('/orders?page=2&limit=2');assert.equal(orders.data.orders.length,1);assert.equal(orders.data.pagination.total,3);assert.equal((await f.other('/orders')).data.pagination.total,0);assert.equal((await f.maintenance('/orders')).status,403);
});
test('transactional order emails are queued once, preserve successful actions on SMTP failure, retry and redact provider errors',async t=>{
  const f=await fixture(t);let order=await f.create(1);assert.equal(f.db.prepare('SELECT COUNT(*) n FROM email_outbox').get().n,1);f.failMail(true);await f.orderMail.flush();assert.equal((await f.buyer('/orders/'+order.id)).status,200);assert.equal(f.db.prepare('SELECT last_error FROM email_outbox').get().last_error,'DELIVERY_FAILED');assert.equal(f.sent.length,0);
  f.advance(31000);f.failMail(false);await f.orderMail.flush();assert.equal(f.sent.length,1);assert.equal(f.sent[0].data.kind,'order_created');assert.equal(f.sent[0].data.test,true);await f.orderMail.flush();assert.equal(f.sent.length,1);
  order=await f.deliver(await f.pay(order));await f.orderMail.flush();assert.equal(f.sent.length,3);assert.deepEqual(f.sent.map(m=>m.data.kind).sort(),['delivered','order_created','shipped']);assert.equal((await f.maintenance('/admin/email-outbox')).status,403);assert.equal((await f.manager('/admin/email-outbox')).data.messages.every(m=>m.status==='sent'),true);
});
test('courier simulator advances tracking automatically, deduplicates events, prevents regression and isolates ownership',async t=>{
  const f=await fixture(t);let order=await f.deliver(await f.pay(await f.create(1)),'shipped'),sh=order.shipments[0];assert.equal((await f.other('/seller/shipments/'+sh.id+'/tracking','POST',{revision:sh.revision})).status,403);
  assert.equal((await f.manager('/admin/shipments/'+sh.id+'/tracking','POST',{revision:sh.revision})).status,200);f.advance(61000);await f.courier.poll();order=(await f.buyer('/orders/'+order.id)).data.order;assert.equal(order.status,'out_for_delivery');f.advance(61000);await f.courier.poll();order=(await f.buyer('/orders/'+order.id)).data.order;assert.equal(order.status,'delivered');
  const count=f.db.prepare('SELECT COUNT(*) n FROM tracking_events').get().n;const event={eventId:'late-event',tag:'InTransit',occurredAt:Date.now()-1000,description:'An old carrier update'};f.courier.applyEvent(sh.id,event);f.courier.applyEvent(sh.id,event);assert.equal(f.db.prepare('SELECT COUNT(*) n FROM tracking_events').get().n,count+1);assert.equal((await f.buyer('/orders/'+order.id)).data.order.status,'delivered');assert.equal(order.shipments[0].trackingIntegration.provider,'local-test');
});
test('AfterShip adapter uses official HTTPS endpoint and verified raw-body webhooks; unsigned, mismatched and duplicate events cannot alter orders',async t=>{
  const requests=[];const f=await fixture(t,{env:{COURIER_MODE:'aftership',AFTERSHIP_API_KEY:'test-only-key',AFTERSHIP_WEBHOOK_SECRET:'test-webhook-secret'},fetchImpl:async(url,options)=>{requests.push({url,options});const body=JSON.parse(options.body);return {ok:true,status:201,json:async()=>({meta:{code:201},data:{...body,tag:'InTransit'}})};}});
  let order=await f.deliver(await f.pay(await f.create(1)),'shipped'),sh=order.shipments[0];const registered=await f.manager('/admin/shipments/'+sh.id+'/tracking','POST',{revision:sh.revision,slug:'test-courier'});assert.equal(registered.status,200);assert.equal(requests[0].url,'https://api.aftership.com/tracking/2026-07/trackings');assert.equal(requests[0].options.headers['as-api-key'],'test-only-key');assert.equal(JSON.parse(requests[0].options.body).id,sh.id);
  const payload={event:'tracking_update',event_id:randomUUID(),ts:Math.floor(Date.now()/1000),msg:{id:sh.id,tracking_number:sh.tracking,tag:'Delivered'}},raw=JSON.stringify(payload),signature=createHmac('sha256','test-webhook-secret').update(raw).digest('base64');
  const post=async(body,sign)=>fetch(f.base+'/api/v1/webhooks/aftership',{method:'POST',headers:{'Content-Type':'application/json','aftership-hmac-sha256':sign},body});assert.equal((await post(raw,'invalid')).status,401);assert.equal((await post(raw,signature)).status,200);assert.equal((await post(raw,signature)).status,200);assert.equal(f.db.prepare('SELECT COUNT(*) n FROM tracking_events').get().n,1);assert.equal((await f.buyer('/orders/'+order.id)).data.order.status,'delivered');assert.equal((await f.manager('/admin/shipments/'+sh.id+'/tracking/simulate','POST',{tag:'Delivered'})).status,404);
});

test('shipping-only refunds complete a previous item refund and concurrent refund attempts cannot double-restock',async t=>{
  const f=await fixture(t);let order=await f.pay(await f.create(1));const body={revision:order.revision,reason:'Refund the purchased unit before dispatch',restock:true,items:[{id:'p1',qty:1}],refundShipping:false};
  const replies=await Promise.all([f.manager('/admin/orders/'+order.id+'/refund','POST',body,{'Idempotency-Key':randomUUID()}),f.manager('/admin/orders/'+order.id+'/refund','POST',body,{'Idempotency-Key':randomUUID()})]);assert.deepEqual(replies.map(r=>r.status).sort(),[200,409]);order=replies.find(r=>r.status===200).data.order;assert.equal(order.refunded,10.01);assert.equal(order.refundable,69);
  const final=await f.manager('/admin/orders/'+order.id+'/refund','POST',{revision:order.revision,reason:'Refund the remaining shipping charge',restock:false,items:[],refundShipping:true},{'Idempotency-Key':randomUUID()});assert.equal(final.status,200);assert.equal(final.data.order.status,'refunded');assert.equal(final.data.order.refunded,79.01);assert.equal(JSON.parse(f.db.prepare("SELECT data FROM products WHERE id='p1'").get().data).primary,30);
});
test('order email retries stop after five failures and Management can requeue without leaking SMTP details',async t=>{
  const f=await fixture(t);await f.create(1);f.failMail(true);for(let i=0;i<5;i++){await f.orderMail.flush();f.advance(3600001);}let row=f.db.prepare('SELECT * FROM email_outbox').get();assert.equal(row.status,'failed');assert.equal(row.attempts,5);assert.ok(!JSON.stringify((await f.manager('/admin/email-outbox')).data).includes('private SMTP message'));
  assert.equal((await f.manager('/admin/email-outbox/'+row.id+'/retry','POST',{})).status,200);f.failMail(false);await f.orderMail.flush();assert.equal(f.sent.length,1);assert.equal((await f.manager('/admin/email-outbox/'+row.id+'/retry','POST',{})).status,409);
});
test('bounded catalog bootstrap and product lookups preserve saved items beyond the first page',async t=>{
  const f=await fixture(t),base=f.commerce.productRow('p1'),data=JSON.parse(base.data);f.commerce.transaction(()=>{for(let i=1;i<=30;i++){const id='QA-PAGE-'+i;f.db.prepare('INSERT INTO products VALUES (?,?)').run(id,JSON.stringify({...data,id,name:'Page fixture '+i}));f.db.prepare('INSERT INTO product_meta(product_id,store_id,sku) VALUES (?,?,?)').run(id,base.store_id,'QA-PAGE-SKU-'+i);}});
  const bootstrap=await f.buyer('/catalog?limit=20');assert.equal(bootstrap.data.products.length,20);assert.equal(bootstrap.data.pagination.total,42);assert.equal(bootstrap.data.products.some(p=>p.id==='QA-PAGE-30'),false);
  const lookup=await f.buyer('/products/lookup?ids=QA-PAGE-30,missing');assert.equal(lookup.data.products.length,1);assert.equal(lookup.data.products[0].id,'QA-PAGE-30');assert.equal((await f.buyer('/products/lookup?ids='+Array.from({length:201},(_,i)=>'p'+i).join(','))).status,422);
  assert.equal((await f.manager('/admin/promotions','POST',{...promotion,code:42})).status,422);
});

test('OpenAPI exposes the new contracts, resolves schema references and documents HMAC separately from browser CSRF',()=>{
  const schema=require('../docs/openapi.json');assert.equal(schema.info.version,'1.2.0');assert.equal(schema.components.schemas.Pagination.properties.limit.maximum,100);assert.ok(schema.components.schemas.OrderRequest.properties.voucherCode);
  for(const name of ['/products','/products/lookup','/orders/quote','/admin/promotions','/products/{id}/reviews','/admin/email-outbox','/webhooks/aftership'])assert.ok(schema.paths[name]);
  function check(value){if(!value||typeof value!=='object')return;if(value.$ref){assert.ok(value.$ref.startsWith('#/components/schemas/'));assert.ok(schema.components.schemas[value.$ref.split('/').at(-1)],value.$ref);}for(const child of Object.values(value))check(child);}check(schema);
  assert.deepEqual(schema.paths['/webhooks/aftership'].post.security,[{aftershipSignature:[]}]);assert.equal(schema.paths['/webhooks/aftership'].post.parameters.some(p=>p.name==='X-CSRF-Token'),false);assert.equal(schema.paths['/admin/promotions'].post.parameters.some(p=>p.name==='X-CSRF-Token'),true);
});
